package com.example.auroramod.gui;

import com.example.auroramod.AuroraConfig;
import com.example.auroramod.HudAnimator;
import com.example.auroramod.MoneyTracker;
import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractSliderButton;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.DoubleConsumer;
import java.util.function.DoubleSupplier;
import java.util.function.IntConsumer;
import java.util.function.IntSupplier;

/** Tabbed settings screen. Everything applies live so you can watch the sky change. */
public class AuroraSettingsScreen extends Screen {
    private static final String[] TABS = {"Aurora", "Motion", "Colors", "Custom", "HUD", "Money", "Display"};
    private static final int TAB_MONEY = 5;
    private static final int WHITE = 0xFFFFFFFF, GOLD = 0xFFFFD700; // ARGB: alpha must be 0xFF
    private static int lastTab = 0;

    private final Screen parent;
    private int colW, gap = 10, x0, x1, y0 = 44, step = 24, slot, panelBottom;
    private final List<Object[]> labels = new ArrayList<>(); // {String text, Integer x, Integer y}

    public AuroraSettingsScreen(Screen parent) {
        super(Component.literal("Aurora Sky Settings"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        AuroraConfig c = AuroraConfig.get();
        slot = 0;
        labels.clear();

        int tw = Math.min(64, (width - 10) / TABS.length);
        int tx = (width - tw * TABS.length) / 2;
        for (int i = 0; i < TABS.length; i++) {
            final int idx = i;
            Component label = Component.literal(TABS[i])
                    .withStyle(i == lastTab ? ChatFormatting.YELLOW : ChatFormatting.WHITE);
            addRenderableWidget(Button.builder(label, b -> {
                lastTab = idx;
                clearWidgets();
                init();
            }).bounds(tx + i * tw, 16, tw, 20).build());
        }

        colW = Math.min(150, (width - 30) / 2);
        x0 = width / 2 - colW - gap / 2;
        x1 = width / 2 + gap / 2;

        switch (lastTab) {
            case 0:
                toggle("Aurora", () -> c.auroraEnabled, v -> c.auroraEnabled = v);
                slider("Intensity", 0, 2, 2, "", () -> c.intensity, v -> c.intensity = (float) v);
                slider("Coverage", 0, 1, 2, "", () -> c.coverage, v -> c.coverage = (float) v);
                slider("Horizon glow", 0, 1, 2, "", () -> c.horizonGlow, v -> c.horizonGlow = (float) v);
                slider("Top fade", 0.5, 3, 2, "", () -> c.falloff, v -> c.falloff = (float) v);
                slider("Base height", 0, 30, 0, "\u00b0", () -> c.baseElevation, v -> c.baseElevation = (float) v);
                slider("Top height", 20, 85, 0, "\u00b0", () -> c.topElevation, v -> c.topElevation = (float) v);
                slider("Rotation", 0, 360, 0, "\u00b0", () -> c.rotation, v -> c.rotation = (float) v);
                slider("Daytime visibility", 0, 1, 2, "", () -> c.dayVisibility, v -> c.dayVisibility = (float) v);
                slider("Rain dimming", 0, 1, 2, "", () -> c.rainDimming, v -> c.rainDimming = (float) v);
                cycle("Quality", AuroraConfig.QUALITY_NAMES, () -> c.quality, v -> c.quality = v);
                break;
            case 1:
                slider("Speed", 0, 3, 2, "x", () -> c.speed, v -> c.speed = (float) v);
                slider("Waves", 0, 2, 2, "", () -> c.waves, v -> c.waves = (float) v);
                slider("Shimmer", 0, 1.5, 2, "", () -> c.shimmer, v -> c.shimmer = (float) v);
                slider("Ray density", 0.3, 2, 2, "x", () -> c.rayDensity, v -> c.rayDensity = (float) v);
                slider("Flicker", 0, 1.5, 2, "", () -> c.flicker, v -> c.flicker = (float) v);
                slider("Color cycling", 0, 2, 2, "", () -> c.colorCycle, v -> c.colorCycle = (float) v);
                break;
            case 2:
                cycle("Preset", AuroraConfig.PRESET_NAMES, () -> c.preset, v -> c.preset = v);
                slider("Hue shift", 0, 360, 0, "\u00b0", () -> c.hueShift, v -> c.hueShift = (float) v);
                slider("Saturation", 0, 1.5, 2, "", () -> c.saturation, v -> c.saturation = (float) v);
                break;
            case 3:
                rgb("Bottom", c.customBottom);
                rgb("Middle", c.customMiddle);
                rgb("Top", c.customTop);
                button("Use Custom preset", () -> {
                    AuroraConfig.get().preset = 7;
                    clearWidgets();
                    init();
                });
                break;
            case 4:
                toggle("Slide HUD", () -> c.slideEnabled, v -> { c.slideEnabled = v; if (!v) HudAnimator.setCentered(false); });
                toggle("Hold key (not toggle)", () -> c.holdMode, v -> c.holdMode = v);
                slider("Duration", 0.1, 2, 2, "s", () -> c.duration, v -> c.duration = (float) v);
                cycle("Easing", AuroraConfig.EASING_NAMES, () -> c.easing, v -> c.easing = v);
                slider("Gap under crosshair", 0, 120, 0, "px", () -> c.gap, v -> c.gap = (float) v);
                slider("Horizontal offset", -200, 200, 0, "px", () -> c.hudOffsetX, v -> c.hudOffsetX = (float) v);
                slider("Scale when centered", 0.5, 2, 2, "x", () -> c.hudScale, v -> c.hudScale = (float) v);
                toggle("Move hotbar", () -> c.moveHotbar, v -> c.moveHotbar = v);
                toggle("Move health/hunger", () -> c.moveStatus, v -> c.moveStatus = v);
                toggle("Move XP bar", () -> c.moveXp, v -> c.moveXp = v);
                toggle("Move item name", () -> c.moveItemName, v -> c.moveItemName = v);
                button("Preview slide", HudAnimator::toggle);
                break;
            case TAB_MONEY:
                toggle("Track money", () -> c.moneyTracking, v -> c.moneyTracking = v);
                toggle("Only on matching server", () -> c.moneyServerOnly, v -> c.moneyServerOnly = v);
                field("Server contains:", c.moneyServer, s -> c.moneyServer = s);
                field("Scoreboard line:", c.moneyKeyword, s -> c.moneyKeyword = s);
                button("Reset session", MoneyTracker::resetSession);
                button("Reset all-time", MoneyTracker::resetLifetime);
                break;
            default:
                toggle("Money HUD", () -> c.moneyHud, v -> c.moneyHud = v);
                toggle("Compact numbers", () -> c.moneyCompact, v -> c.moneyCompact = v);
                cycle("Corner", AuroraConfig.ANCHOR_NAMES, () -> c.moneyAnchor, v -> c.moneyAnchor = v);
                slider("X offset", 0, 300, 0, "px", () -> c.moneyX, v -> c.moneyX = (float) v);
                slider("Y offset", 0, 300, 0, "px", () -> c.moneyY, v -> c.moneyY = (float) v);
                slider("Scale", 0.5, 2, 2, "x", () -> c.moneyScale, v -> c.moneyScale = (float) v);
                slider("Background", 0, 1, 2, "", () -> c.moneyBg, v -> c.moneyBg = (float) v);
                toggle("Earned / lost", () -> c.showEarnedLost, v -> c.showEarnedLost = v);
                toggle("Per hour", () -> c.showRate, v -> c.showRate = v);
                toggle("Session time", () -> c.showTime, v -> c.showTime = v);
                toggle("All-time total", () -> c.showLifetime, v -> c.showLifetime = v);
                slider("Recent changes", 0, 10, 0, "", () -> c.recentCount, v -> c.recentCount = (int) Math.round(v));
                break;
        }

        int footerY = y0 + 6 * step + 4;
        panelBottom = footerY + 26;
        addRenderableWidget(Button.builder(Component.literal("Reset all"), b -> {
            AuroraConfig.reset();
            clearWidgets();
            init();
        }).bounds(x0, footerY, colW, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Done"), b -> onClose())
                .bounds(x1, footerY, colW, 20).build());
    }

    // ---- widget helpers (each takes the next grid slot) ----

    private int sx() { return slot % 2 == 0 ? x0 : x1; }
    private int sy() { return y0 + (slot / 2) * step; }

    private void slider(String label, double min, double max, int decimals, String unit,
                        DoubleSupplier get, DoubleConsumer set) {
        addRenderableWidget(new ConfigSlider(sx(), sy(), colW, label, min, max, decimals, unit, get, set));
        slot++;
    }

    private void toggle(String label, BooleanSupplier get, Consumer<Boolean> set) {
        Button w = Button.builder(toggleText(label, get.getAsBoolean()), btn -> {
            boolean v = !get.getAsBoolean();
            set.accept(v);
            btn.setMessage(toggleText(label, v));
        }).bounds(sx(), sy(), colW, 20).build();
        addRenderableWidget(w);
        slot++;
    }

    private static Component toggleText(String label, boolean on) {
        return Component.literal(label + ": ").append(Component.literal(on ? "ON" : "OFF")
                .withStyle(on ? ChatFormatting.GREEN : ChatFormatting.RED));
    }

    private void cycle(String label, String[] names, IntSupplier get, IntConsumer set) {
        Button w = Button.builder(Component.literal(label + ": " + names[get.getAsInt()]), btn -> {
            int v = (get.getAsInt() + 1) % names.length;
            set.accept(v);
            btn.setMessage(Component.literal(label + ": " + names[v]));
        }).bounds(sx(), sy(), colW, 20).build();
        addRenderableWidget(w);
        slot++;
    }

    private void button(String label, Runnable action) {
        addRenderableWidget(Button.builder(Component.literal(label), b -> action.run())
                .bounds(sx(), sy(), colW, 20).build());
        slot++;
    }

    /** A label on the left and a text box on the right, on one row. */
    private void field(String label, String value, Consumer<String> set) {
        if (slot % 2 == 1) slot++;
        labels.add(new Object[]{label, x0 + 2, sy() + 6});
        slot++;
        EditBox f = new EditBox(font, sx(), sy(), colW, 20, Component.literal(label));
        f.setMaxLength(40);
        f.setValue(value);
        f.setResponder(set);
        addRenderableWidget(f);
        slot++;
    }

    private void rgb(String name, float[] col) {
        String[] ch = {"R", "G", "B"};
        for (int i = 0; i < 3; i++) {
            final int idx = i;
            slider(name + " " + ch[i], 0, 255, 0, "",
                    () -> col[idx] * 255.0, v -> col[idx] = (float) (v / 255.0));
        }
    }

    // ---- screen plumbing ----

    @Override
    public void renderBackground(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        // No blur: keep the sky and HUD visible behind the panel so changes preview live.
        int pw = colW * 2 + gap + 24;
        graphics.fill(width / 2 - pw / 2, 2, width / 2 + pw / 2, panelBottom, 0x66000000);
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        super.render(graphics, mouseX, mouseY, partialTick);
        graphics.drawCenteredString(font, title, width / 2, 5, WHITE);
        for (Object[] l : labels) {
            graphics.drawString(font, (String) l[0], (Integer) l[1], (Integer) l[2], WHITE);
        }
        if (lastTab == TAB_MONEY) {
            graphics.drawString(font, "Status: " + MoneyTracker.status(), x0, y0 + 4 * step, GOLD);
        }
    }

    @Override
    public boolean isPauseScreen() {
        return false; // keep the world (and the aurora) running while you tweak
    }

    @Override
    public void onClose() {
        AuroraConfig.save();
        minecraft.setScreen(parent);
    }

    private static final class ConfigSlider extends AbstractSliderButton {
        private final String label, unit;
        private final double min, max;
        private final int decimals;
        private final DoubleConsumer set;

        ConfigSlider(int x, int y, int w, String label, double min, double max, int decimals, String unit,
                     DoubleSupplier get, DoubleConsumer set) {
            super(x, y, w, 20, Component.empty(), Math.max(0, Math.min(1, (get.getAsDouble() - min) / (max - min))));
            this.label = label;
            this.unit = unit;
            this.min = min;
            this.max = max;
            this.decimals = decimals;
            this.set = set;
            updateMessage();
        }

        private double current() { return min + (max - min) * value; }

        @Override
        protected void updateMessage() {
            setMessage(Component.literal(label + ": " + String.format("%." + decimals + "f", current()) + unit));
        }

        @Override
        protected void applyValue() {
            set.accept(current());
        }
    }
}
