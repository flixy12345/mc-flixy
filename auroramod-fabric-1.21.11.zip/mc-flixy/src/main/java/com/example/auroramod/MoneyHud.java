package com.example.auroramod;

import com.example.auroramod.gui.AuroraSettingsScreen;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/** Draws the money tracker panel. */
public final class MoneyHud {
    // ARGB: the alpha byte must be 0xFF or the text is invisible in 1.21.6+
    private static final int GREEN = 0xFF55FF55, RED = 0xFFFF5555, WHITE = 0xFFFFFFFF,
            GOLD = 0xFFFFD700, GRAY = 0xFFAAAAAA;

    private record Line(String text, int color) {}

    private MoneyHud() {}

    public static void render(GuiGraphics graphics) {
        AuroraConfig c = AuroraConfig.get();
        Minecraft mc = Minecraft.getInstance();
        if (!c.moneyHud || mc.options.hideGui) return;

        double bal, gained, lost, elapsed;
        List<Double> recent;
        if (MoneyTracker.isActive()) {
            bal = MoneyTracker.balance();
            gained = MoneyTracker.gained();
            lost = MoneyTracker.lost();
            elapsed = MoneyTracker.elapsedSeconds();
            recent = MoneyTracker.recent();
        } else if (mc.screen instanceof AuroraSettingsScreen) {
            // sample numbers so you can position and style the panel from the settings screen
            bal = 2_450_000; gained = 185_000; lost = 40_000; elapsed = 1520;
            recent = new ArrayList<>(Arrays.asList(12_500.0, -5_000.0, 80_000.0));
        } else {
            return;
        }

        boolean cp = c.moneyCompact;
        double net = gained - lost;
        List<Line> lines = new ArrayList<>();
        lines.add(new Line("Balance: $" + MoneyTracker.format(bal, cp), GOLD));
        lines.add(new Line("Session: " + MoneyTracker.signed(net, cp), net >= 0 ? GREEN : RED));
        if (c.showEarnedLost) {
            lines.add(new Line("Earned: " + MoneyTracker.signed(gained, cp), GREEN));
            lines.add(new Line("Lost: -$" + MoneyTracker.format(lost, cp), RED));
        }
        if (c.showRate) {
            if (elapsed >= 30) {
                double perHour = net / (elapsed / 3600.0);
                lines.add(new Line("Per hour: " + MoneyTracker.signed(perHour, cp) + "/h", perHour >= 0 ? GREEN : RED));
            } else {
                lines.add(new Line("Per hour: --", GRAY));
            }
        }
        if (c.showTime) {
            long s = (long) elapsed;
            lines.add(new Line(String.format("Time: %02d:%02d:%02d", s / 3600, (s / 60) % 60, s % 60), WHITE));
        }
        if (c.showLifetime) {
            double lt = c.lifetimeGained - c.lifetimeLost;
            lines.add(new Line("All-time: " + MoneyTracker.signed(lt, cp), lt >= 0 ? GREEN : RED));
        }
        int n = Math.min(c.recentCount, recent.size());
        for (int i = 0; i < n; i++) {
            double d = recent.get(i);
            lines.add(new Line("  " + MoneyTracker.signed(d, cp), d >= 0 ? GREEN : RED));
        }

        Font font = mc.font;
        int lineH = font.lineHeight + 1;
        int w = 0;
        for (Line l : lines) w = Math.max(w, font.width(l.text()));
        w += 8;
        int h = lines.size() * lineH + 5;

        float s = c.moneyScale;
        float boxW = w * s, boxH = h * s;
        int sw = mc.getWindow().getGuiScaledWidth(), sh = mc.getWindow().getGuiScaledHeight();
        boolean right = c.moneyAnchor == 1 || c.moneyAnchor == 3;
        boolean bottom = c.moneyAnchor == 2 || c.moneyAnchor == 3;
        float x = right ? sw - boxW - c.moneyX : c.moneyX;
        float y = bottom ? sh - boxH - c.moneyY : c.moneyY;

        graphics.pose().pushMatrix();
        graphics.pose().translate(x, y);
        graphics.pose().scale(s, s);

        int alpha = Math.round(Math.max(0f, Math.min(1f, c.moneyBg)) * 255f);
        if (alpha > 0) graphics.fill(0, 0, w, h, alpha << 24);
        for (int i = 0; i < lines.size(); i++) {
            Line l = lines.get(i);
            graphics.drawString(font, l.text(), 4, 3 + i * lineH, l.color());
        }

        graphics.pose().popMatrix();
    }
}
