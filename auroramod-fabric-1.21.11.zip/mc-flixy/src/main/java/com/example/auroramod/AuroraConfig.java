package com.example.auroramod;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;

/** All user-facing settings. Saved to config/auroramod.json. */
public final class AuroraConfig {
    public static final String[] PRESET_NAMES = {
            "Classic", "Polar", "Violet", "Crimson", "Sunset", "Ice", "Rainbow", "Custom"};
    public static final String[] EASING_NAMES = {
            "Smoother", "Smooth", "Ease Out", "Sine", "Overshoot", "Linear"};
    public static final String[] QUALITY_NAMES = {"Low", "Medium", "High", "Ultra"};
    public static final String[] ANCHOR_NAMES = {"Top left", "Top right", "Bottom left", "Bottom right"};

    // ---- Aurora ----
    public boolean auroraEnabled = true;
    public float intensity = 1.0f;       // overall brightness
    public float coverage = 0.6f;        // how much of the horizon is lit
    public float horizonGlow = 0.3f;     // soft glow band at the horizon
    public float falloff = 1.4f;         // how quickly curtains fade toward the top
    public float baseElevation = 6f;     // degrees above horizon
    public float topElevation = 64f;     // degrees above horizon
    public float rotation = 0f;          // degrees around the horizon
    public float dayVisibility = 0f;     // 0 = night only, 1 = always visible
    public float rainDimming = 0.85f;    // how much rain hides it
    public int quality = 2;              // index into QUALITY_NAMES

    // ---- Motion ----
    public float speed = 1.0f;
    public float waves = 1.0f;
    public float shimmer = 1.0f;
    public float rayDensity = 1.0f;
    public float flicker = 1.0f;
    public float colorCycle = 0.0f;      // 0 = static colors

    // ---- Colors ----
    public int preset = 0;               // index into PRESET_NAMES
    public float hueShift = 0f;          // degrees
    public float saturation = 1.0f;

    public float[] customBottom = {0.25f, 1.00f, 0.45f};
    public float[] customMiddle = {0.10f, 0.60f, 1.00f};
    public float[] customTop    = {0.80f, 0.25f, 0.85f};

    // ---- HUD slide ----
    public boolean slideEnabled = true;
    public boolean holdMode = false;     // hold the key instead of toggling
    public float duration = 0.7f;        // seconds
    public int easing = 0;               // index into EASING_NAMES
    public float gap = 10f;              // px under the crosshair
    public float hudOffsetX = 0f;        // px
    public float hudScale = 1.0f;        // scale while centered
    public boolean moveHotbar = true;
    public boolean moveStatus = true;
    public boolean moveXp = true;
    public boolean moveItemName = true;

    // ---- Money tracker ----
    public boolean moneyTracking = true;
    public boolean moneyServerOnly = true;
    public String moneyServer = "donutsmp";   // server address must contain this
    public String moneyKeyword = "Money";     // scoreboard line to read
    public boolean moneyHud = true;
    public boolean moneyCompact = true;       // 1.25M instead of 1,250,000
    public int moneyAnchor = 0;               // index into ANCHOR_NAMES
    public float moneyX = 6f, moneyY = 6f;    // px from the anchored corner
    public float moneyScale = 1.0f;
    public float moneyBg = 0.45f;             // background opacity
    public boolean showEarnedLost = true;
    public boolean showRate = true;
    public boolean showTime = true;
    public boolean showLifetime = false;
    public int recentCount = 3;               // recent changes listed (0-10)
    public double lifetimeGained = 0;
    public double lifetimeLost = 0;

    // ---- storage ----
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static AuroraConfig instance = new AuroraConfig();

    public static AuroraConfig get() { return instance; }

    private static Path path() {
        return FabricLoader.getInstance().getConfigDir().resolve("auroramod.json");
    }

    public static void load() {
        try {
            Path p = path();
            if (Files.exists(p)) {
                AuroraConfig loaded = GSON.fromJson(Files.readString(p), AuroraConfig.class);
                if (loaded != null) instance = loaded;
            }
        } catch (Exception e) {
            instance = new AuroraConfig();
        }
        instance.sanitize();
    }

    public static void save() {
        try {
            instance.sanitize();
            Files.writeString(path(), GSON.toJson(instance));
        } catch (Exception ignored) {
        }
    }

    public static void reset() {
        instance = new AuroraConfig();
    }

    private void sanitize() {
        preset = Math.floorMod(preset, PRESET_NAMES.length);
        easing = Math.floorMod(easing, EASING_NAMES.length);
        quality = Math.floorMod(quality, QUALITY_NAMES.length);
        moneyAnchor = Math.floorMod(moneyAnchor, ANCHOR_NAMES.length);
        if (moneyServer == null) moneyServer = "donutsmp";
        if (moneyKeyword == null || moneyKeyword.isBlank()) moneyKeyword = "Money";
        recentCount = Math.max(0, Math.min(10, recentCount));
        if (customBottom == null || customBottom.length < 3) customBottom = new float[]{0.25f, 1f, 0.45f};
        if (customMiddle == null || customMiddle.length < 3) customMiddle = new float[]{0.1f, 0.6f, 1f};
        if (customTop == null || customTop.length < 3) customTop = new float[]{0.8f, 0.25f, 0.85f};
        if (topElevation < baseElevation + 5f) topElevation = baseElevation + 5f;
    }
}
