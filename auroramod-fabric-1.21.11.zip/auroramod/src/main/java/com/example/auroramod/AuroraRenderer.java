package com.example.auroramod;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.buffers.GpuBufferSlice;
import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.systems.CommandEncoder;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.ByteBufferBuilder;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.MeshData;
import com.mojang.blaze3d.vertex.VertexFormat;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.minecraft.Util;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.renderer.MappableRingBuffer;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.resources.Identifier;
import net.minecraft.world.level.Level;
import org.joml.Matrix4f;
import org.joml.Matrix4fc;
import org.joml.Vector3f;
import org.joml.Vector4f;
import org.lwjgl.system.MemoryUtil;

import java.util.OptionalDouble;
import java.util.OptionalInt;

/**
 * Animated aurora borealis curtains + horizon glow on a dome around the camera.
 * Drawn with a custom render pipeline (additive blend, depth-tested, no depth write),
 * so terrain and nearby objects correctly cover it.
 */
public final class AuroraRenderer {
    private static final RenderPipeline PIPELINE = RenderPipelines.register(
            RenderPipeline.builder(RenderPipelines.DEBUG_FILLED_SNIPPET)
                    .withLocation(Identifier.fromNamespaceAndPath(AuroraMod.MOD_ID, "pipeline/aurora"))
                    .withVertexFormat(DefaultVertexFormat.POSITION_COLOR, VertexFormat.Mode.QUADS)
                    .withBlend(BlendFunction.ADDITIVE)               // colors are premultiplied by alpha below
                    .withDepthTestFunction(DepthTestFunction.LEQUAL_DEPTH_TEST)
                    .withDepthWrite(false)
                    .withCull(false)
                    .build());

    private static final ByteBufferBuilder ALLOCATOR = new ByteBufferBuilder(1 << 18);
    private static MappableRingBuffer vertexBuffer;

    private static final Vector4f COLOR_MODULATOR = new Vector4f(1f, 1f, 1f, 1f);
    private static final Vector3f MODEL_OFFSET = new Vector3f();
    private static final Matrix4f TEXTURE_MATRIX = new Matrix4f();

    private static final float TAU = (float) (Math.PI * 2.0);
    private static final float RAD = (float) (Math.PI / 180.0);
    private static final int[][] QUALITY = {{64, 12}, {96, 18}, {128, 24}, {192, 32}};

    private static final int MAX_N = (192 + 1) * (32 + 1);
    private static final float[] px = new float[MAX_N], py = new float[MAX_N], pz = new float[MAX_N];
    private static final float[] cr = new float[MAX_N], cg = new float[MAX_N], cb = new float[MAX_N], ca = new float[MAX_N];

    private static final float[] KEY_POS = {0f, 0.3f, 0.65f, 1f};
    private static final float[][][] PRESETS = {
            {{0.25f, 1f, 0.45f}, {0.10f, 0.95f, 0.70f}, {0.35f, 0.50f, 1f}, {0.80f, 0.25f, 0.85f}}, // Classic
            {{0.30f, 1f, 0.50f}, {0.10f, 1f, 0.80f}, {0.10f, 0.70f, 1f}, {0.20f, 0.40f, 1f}},       // Polar
            {{0.50f, 0.40f, 1f}, {0.70f, 0.30f, 1f}, {0.95f, 0.35f, 0.90f}, {1f, 0.50f, 0.80f}},     // Violet
            {{1f, 0.25f, 0.30f}, {1f, 0.30f, 0.50f}, {0.85f, 0.30f, 0.80f}, {0.50f, 0.20f, 0.90f}},  // Crimson
            {{1f, 0.70f, 0.20f}, {1f, 0.45f, 0.35f}, {0.95f, 0.30f, 0.60f}, {0.50f, 0.25f, 0.80f}},  // Sunset
            {{0.90f, 1f, 1f}, {0.50f, 0.95f, 1f}, {0.35f, 0.70f, 1f}, {0.40f, 0.50f, 1f}},           // Ice
            {{1f, 0.30f, 0.30f}, {1f, 0.90f, 0.30f}, {0.30f, 1f, 0.50f}, {0.40f, 0.50f, 1f}}         // Rainbow base
    };
    private static final int RAINBOW = 6, CUSTOM = 7;

    // per-frame state
    private static long lastMs = Util.getMillis();
    private static float animTime = 0f, hueTime = 0f;
    private static float[][] activeKeys = PRESETS[0];
    private static boolean activeRainbow = false;
    private static float activeHue = 0f, activeSat = 1f;
    private static final float[] tmp = new float[3];
    private static float radius = 160f;

    private AuroraRenderer() {}

    // ---------- helpers ----------

    private static float clamp(float v, float lo, float hi) { return v < lo ? lo : Math.min(v, hi); }
    private static float sin(float v) { return (float) Math.sin(v); }
    private static float cos(float v) { return (float) Math.cos(v); }
    private static float lerp(float a, float b, float t) { return a + (b - a) * t; }

    private static float smooth(float a, float b, float x) {
        float t = clamp((x - a) / (b - a), 0f, 1f);
        return t * t * (3f - 2f * t);
    }

    private static float envelope(float theta0, float t, float lo, float hi) {
        float e1 = 0.5f + 0.5f * sin(2 * theta0 + 0.11f * t);
        float e2 = 0.5f + 0.5f * sin(3 * theta0 - 0.07f * t + 1.3f);
        return smooth(lo, hi, e1 * 0.6f + e2 * 0.5f);
    }

    /** Sun height: 1 at noon, -1 at midnight (same curve vanilla has always used). */
    private static float sunHeight(ClientLevel level) {
        long dayTime = level.getDayTime();
        float frac = (float) (((dayTime % 24000L) + 24000L) % 24000L) / 24000f;
        float d = frac - 0.25f;
        d -= (float) Math.floor(d);
        float e = 0.5f - cos(d * (float) Math.PI) / 2f;
        float angle = d + (e - d) / 3f;
        return cos(angle * TAU);
    }

    private static void colorAt(float h, float theta0, float[] out) {
        int k = 0;
        while (k < 2 && h > KEY_POS[k + 1]) k++;
        float u = clamp((h - KEY_POS[k]) / (KEY_POS[k + 1] - KEY_POS[k]), 0f, 1f);
        float[] a = activeKeys[k], b = activeKeys[k + 1];
        float r = lerp(a[0], b[0], u), g = lerp(a[1], b[1], u), bl = lerp(a[2], b[2], u);
        float hue = activeHue + (activeRainbow ? theta0 / TAU * 360f : 0f);
        adjust(r, g, bl, hue, activeSat, out);
    }

    /** Rotate hue (degrees) and scale saturation of an RGB color. */
    private static void adjust(float r, float g, float b, float hueDeg, float sat, float[] out) {
        float max = Math.max(r, Math.max(g, b)), min = Math.min(r, Math.min(g, b)), d = max - min;
        float h;
        if (d < 1e-5f) h = 0f;
        else if (max == r) h = ((g - b) / d) % 6f;
        else if (max == g) h = (b - r) / d + 2f;
        else h = (r - g) / d + 4f;
        h = h * 60f + hueDeg;
        h = ((h % 360f) + 360f) % 360f;
        float s = max <= 0f ? 0f : clamp(d / max * sat, 0f, 1f);
        float v = max;
        float cc = v * s, hp = h / 60f;
        float x = cc * (1f - Math.abs(hp % 2f - 1f)), m = v - cc;
        float r1, g1, b1;
        switch ((int) hp) {
            case 0:  r1 = cc; g1 = x;  b1 = 0;  break;
            case 1:  r1 = x;  g1 = cc; b1 = 0;  break;
            case 2:  r1 = 0;  g1 = cc; b1 = x;  break;
            case 3:  r1 = 0;  g1 = x;  b1 = cc; break;
            case 4:  r1 = x;  g1 = 0;  b1 = cc; break;
            default: r1 = cc; g1 = 0;  b1 = x;  break;
        }
        out[0] = r1 + m; out[1] = g1 + m; out[2] = b1 + m;
    }

    private static void put(BufferBuilder buf, Matrix4fc pose, float x, float y, float z,
                            float r, float g, float b, float a) {
        buf.addVertex(pose, x, y, z).setColor(r * a, g * a, b * a, a);
    }

    // ---------- main entry ----------

    public static void render(WorldRenderContext context) {
        AuroraConfig c = AuroraConfig.get();
        if (!c.auroraEnabled) return;

        Minecraft mc = Minecraft.getInstance();
        ClientLevel level = mc.level;
        if (level == null || mc.player == null) return;

        // advance animation clocks (accumulated, so changing speed never causes jumps)
        long now = Util.getMillis();
        float dt = Math.min((now - lastMs) / 1000f, 0.1f);
        lastMs = now;
        animTime += dt * c.speed;
        hueTime += dt * c.colorCycle * 30f;

        if (level.dimension() != Level.OVERWORLD) return;
        if (mc.player.isUnderWater()) return;

        float night = smooth(-0.05f, 0.35f, -sunHeight(level));
        float vis = Math.max(night, c.dayVisibility);
        float strength = vis * (1f - c.rainDimming * level.getRainLevel(1.0f)) * c.intensity;
        if (strength <= 0.01f) return;

        // Put the dome just beyond the terrain so near terrain hides it but the sky doesn't.
        radius = Math.max(60f, mc.options.getEffectiveRenderDistance() * 16f * 1.8f);

        // colors for this frame
        if (c.preset == CUSTOM) {
            activeKeys = new float[][]{c.customBottom, c.customMiddle, c.customMiddle, c.customTop};
        } else {
            activeKeys = PRESETS[Math.min(c.preset, PRESETS.length - 1)];
        }
        activeRainbow = c.preset == RAINBOW;
        activeHue = c.hueShift + hueTime;
        activeSat = c.saturation;

        float flick = 1f + 0.12f * c.flicker * (sin(animTime * 0.8f) - 1f);
        float lo = 0.9f - c.coverage;
        float hi = lo + 0.65f;
        float rot = c.rotation * RAD;
        float base = c.baseElevation * RAD;
        float top = Math.max(c.topElevation, c.baseElevation + 5f) * RAD;
        int f1 = Math.max(1, Math.round(47 * c.rayDensity));
        int f2 = Math.max(1, Math.round(113 * c.rayDensity));
        float wave = c.waves;
        float t = animTime;

        int seg = QUALITY[c.quality][0], rows = QUALITY[c.quality][1];
        int rows1 = rows + 1;

        // ---- curtain grid ----
        for (int i = 0; i <= seg; i++) {
            float theta0 = (float) i / seg * TAU;
            float envelope = envelope(theta0, t, lo, hi);

            float rawRay = 0.65f + 0.35f * sin(f1 * theta0 + 1.7f * sin(5 * theta0 + 0.4f * t) + 0.9f * t);
            rawRay *= 0.8f + 0.2f * sin(f2 * theta0 - 1.3f * t);
            float ray = Math.max(0f, 1f + c.shimmer * (rawRay - 1f));

            for (int j = 0; j <= rows; j++) {
                float h = (float) j / rows;
                int k = i * rows1 + j;

                float elev = lerp(base, top, h) + 4f * RAD * wave * sin(3 * theta0 + 0.25f * t) * (1f - h);
                float th = theta0 + rot + wave * (
                        0.07f * sin(4 * theta0 + 0.35f * t + h * 2.5f)
                      + 0.03f * sin(9 * theta0 - 0.5f * t + h * 4f));

                float ce = cos(elev);
                px[k] = radius * ce * cos(th);
                py[k] = radius * sin(elev);
                pz[k] = radius * ce * sin(th);

                colorAt(h, theta0, tmp);
                cr[k] = tmp[0]; cg[k] = tmp[1]; cb[k] = tmp[2];

                float vertical = smooth(0f, 0.05f, h) * (float) Math.pow(1f - h, c.falloff) * (1f - 0.4f * h);
                ca[k] = Math.min(1f, strength * envelope * ray * flick * vertical * 0.6f);
            }
        }

        // camera-space transform (rotation only; the dome is centered on the camera)
        Matrix4fc pose = context.matrices().last().pose();
        BufferBuilder buf = new BufferBuilder(ALLOCATOR, PIPELINE.getVertexFormatMode(), PIPELINE.getVertexFormat());

        for (int i = 0; i < seg; i++) {
            for (int j = 0; j < rows; j++) {
                int a = i * rows1 + j;
                int b = a + 1;
                int cc = (i + 1) * rows1 + j + 1;
                int d = (i + 1) * rows1 + j;
                put(buf, pose, px[a], py[a], pz[a], cr[a], cg[a], cb[a], ca[a]);
                put(buf, pose, px[b], py[b], pz[b], cr[b], cg[b], cb[b], ca[b]);
                put(buf, pose, px[cc], py[cc], pz[cc], cr[cc], cg[cc], cb[cc], ca[cc]);
                put(buf, pose, px[d], py[d], pz[d], cr[d], cg[d], cb[d], ca[d]);
            }
        }

        // ---- horizon glow ----
        if (c.horizonGlow > 0.01f) {
            int gs = 64, gr = 6;
            for (int i = 0; i < gs; i++) {
                for (int j = 0; j < gr; j++) {
                    glowVertex(buf, pose, i, j, gs, gr, strength, flick, lo, hi, rot, c);
                    glowVertex(buf, pose, i, j + 1, gs, gr, strength, flick, lo, hi, rot, c);
                    glowVertex(buf, pose, i + 1, j + 1, gs, gr, strength, flick, lo, hi, rot, c);
                    glowVertex(buf, pose, i + 1, j, gs, gr, strength, flick, lo, hi, rot, c);
                }
            }
        }

        drawBuffer(mc, buf);
    }

    private static void glowVertex(BufferBuilder buf, Matrix4fc pose, int i, int j, int gs, int gr,
                                   float strength, float flick, float lo, float hi, float rot, AuroraConfig c) {
        float theta0 = (float) i / gs * TAU;
        float v = (float) j / gr;
        float elev = lerp(-3f * RAD, 32f * RAD, v);
        float ce = cos(elev);
        float th = theta0 + rot;

        float env = 0.35f + 0.65f * envelope(theta0, animTime, lo, hi);
        colorAt(0.05f, theta0, tmp);
        float a = Math.min(1f, strength * c.horizonGlow * env * flick * (1f - v) * (1f - v) * 0.45f);
        put(buf, pose, radius * ce * cos(th), radius * sin(elev), radius * ce * sin(th), tmp[0], tmp[1], tmp[2], a);
    }

    // ---------- drawing (follows the Fabric 1.21.11 custom-pipeline guide) ----------

    private static void drawBuffer(Minecraft client, BufferBuilder buffer) {
        MeshData builtBuffer = buffer.buildOrThrow();
        MeshData.DrawState drawParameters = builtBuffer.drawState();
        VertexFormat format = drawParameters.format();

        GpuBuffer vertices = upload(drawParameters, format, builtBuffer);
        draw(client, builtBuffer, drawParameters, vertices, format);

        // Rotate the vertex buffer so we are less likely to use buffers that the GPU is using
        vertexBuffer.rotate();
    }

    private static GpuBuffer upload(MeshData.DrawState drawParameters, VertexFormat format, MeshData builtBuffer) {
        int vertexBufferSize = drawParameters.vertexCount() * format.getVertexSize();

        if (vertexBuffer == null || vertexBuffer.size() < vertexBufferSize) {
            if (vertexBuffer != null) {
                vertexBuffer.close();
            }
            vertexBuffer = new MappableRingBuffer(() -> AuroraMod.MOD_ID + " aurora vertices",
                    GpuBuffer.USAGE_VERTEX | GpuBuffer.USAGE_MAP_WRITE, vertexBufferSize);
        }

        CommandEncoder commandEncoder = RenderSystem.getDevice().createCommandEncoder();
        try (GpuBuffer.MappedView mappedView = commandEncoder.mapBuffer(
                vertexBuffer.currentBuffer().slice(0, builtBuffer.vertexBuffer().remaining()), false, true)) {
            MemoryUtil.memCopy(builtBuffer.vertexBuffer(), mappedView.data());
        }

        return vertexBuffer.currentBuffer();
    }

    private static void draw(Minecraft client, MeshData builtBuffer, MeshData.DrawState drawParameters,
                             GpuBuffer vertices, VertexFormat format) {
        // Quads use the shared sequential index buffer (no sorting needed: additive blending is order-independent)
        RenderSystem.AutoStorageIndexBuffer shapeIndexBuffer = RenderSystem.getSequentialBuffer(PIPELINE.getVertexFormatMode());
        GpuBuffer indices = shapeIndexBuffer.getBuffer(drawParameters.indexCount());
        VertexFormat.IndexType indexType = shapeIndexBuffer.type();

        GpuBufferSlice dynamicTransforms = RenderSystem.getDynamicUniforms()
                .writeTransform(RenderSystem.getModelViewMatrix(), COLOR_MODULATOR, MODEL_OFFSET, TEXTURE_MATRIX);

        try (RenderPass renderPass = RenderSystem.getDevice()
                .createCommandEncoder()
                .createRenderPass(() -> AuroraMod.MOD_ID + " aurora",
                        client.getMainRenderTarget().getColorTextureView(), OptionalInt.empty(),
                        client.getMainRenderTarget().getDepthTextureView(), OptionalDouble.empty())) {
            renderPass.setPipeline(PIPELINE);

            RenderSystem.bindDefaultUniforms(renderPass);
            renderPass.setUniform("DynamicTransforms", dynamicTransforms);

            renderPass.setVertexBuffer(0, vertices);
            renderPass.setIndexBuffer(indices, indexType);

            renderPass.drawIndexed(0, 0, drawParameters.indexCount(), 1);
        }

        builtBuffer.close();
    }

    public static void close() {
        ALLOCATOR.close();
        if (vertexBuffer != null) {
            vertexBuffer.close();
            vertexBuffer = null;
        }
    }
}
