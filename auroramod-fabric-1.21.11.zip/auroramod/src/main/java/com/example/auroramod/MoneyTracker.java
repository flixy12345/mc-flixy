package com.example.auroramod;

import net.minecraft.Util;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.multiplayer.ServerData;
import net.minecraft.network.chat.Component;
import net.minecraft.world.scores.DisplaySlot;
import net.minecraft.world.scores.Objective;
import net.minecraft.world.scores.PlayerScoreEntry;
import net.minecraft.world.scores.PlayerTeam;
import net.minecraft.world.scores.Scoreboard;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Passive, client-side money tracker. It only READS the sidebar scoreboard that the
 * server already sends you, and counts every change in the balance as money earned
 * or lost. It sends nothing anywhere and has no network code.
 */
public final class MoneyTracker {
    private static final Pattern NUMBER =
            Pattern.compile("(\\d[\\d,]*(?:\\.\\d+)?)\\s*([kKmMbBtT])?(?![a-zA-Z])");

    private static double balance;
    private static boolean baselineValid = false;
    private static double gained, lost, elapsed;
    private static final ArrayDeque<Double> recent = new ArrayDeque<>();

    private static long lastMs = Util.getMillis();
    private static long lastSaveMs = lastMs;
    private static boolean dirty = false;
    private static String status = "Starting up";

    private MoneyTracker() {}

    // ---------- public API ----------

    public static boolean isActive() { return baselineValid && AuroraConfig.get().moneyTracking; }
    public static double balance() { return balance; }
    public static double gained() { return gained; }
    public static double lost() { return lost; }
    public static double net() { return gained - lost; }
    public static double elapsedSeconds() { return elapsed; }
    public static List<Double> recent() { return new ArrayList<>(recent); }
    public static String status() { return status; }

    public static void resetSession() {
        gained = 0;
        lost = 0;
        elapsed = 0;
        recent.clear();
    }

    public static void resetLifetime() {
        AuroraConfig c = AuroraConfig.get();
        c.lifetimeGained = 0;
        c.lifetimeLost = 0;
        dirty = true;
    }

    /** Called when joining or leaving a server so we never count a jump between servers. */
    public static void onConnectionChange() {
        baselineValid = false;
    }

    // ---------- per-tick update ----------

    public static void tick(Minecraft mc) {
        AuroraConfig c = AuroraConfig.get();
        long now = Util.getMillis();
        if (now - lastMs < 200) return;               // check ~5 times per second
        float dt = Math.min((now - lastMs) / 1000f, 1f);
        lastMs = now;

        if (dirty && now - lastSaveMs > 30_000) {
            AuroraConfig.save();
            dirty = false;
            lastSaveMs = now;
        }

        if (!c.moneyTracking) {
            status = "Tracking is off";
            baselineValid = false;
            return;
        }
        if (mc.level == null || mc.player == null) {
            status = "Not in a world";
            baselineValid = false;
            return;
        }
        if (c.moneyServerOnly && !serverMatches(mc, c.moneyServer)) {
            status = "Not on a server matching '" + c.moneyServer + "'";
            baselineValid = false;
            return;
        }

        Double v = readBalance(mc.level, c.moneyKeyword);
        if (v == null) {
            // Keep the old baseline: if the line flickers, the next good read still counts correctly.
            status = "Waiting for a scoreboard line containing '" + c.moneyKeyword + "'";
            return;
        }

        if (baselineValid) {
            elapsed += dt;
            double d = v - balance;
            if (Math.abs(d) >= 0.5) {
                if (d > 0) {
                    gained += d;
                    c.lifetimeGained += d;
                } else {
                    lost += -d;
                    c.lifetimeLost += -d;
                }
                recent.addFirst(d);
                while (recent.size() > 10) recent.removeLast();
                dirty = true;
            }
        }
        balance = v;
        baselineValid = true;
        status = "Tracking (balance $" + format(v, c.moneyCompact) + ")";
    }

    private static boolean serverMatches(Minecraft mc, String needle) {
        ServerData info = mc.getCurrentServer();
        if (info == null || info.ip == null) return false;
        return info.ip.toLowerCase(Locale.ROOT).contains(needle.toLowerCase(Locale.ROOT));
    }

    // ---------- scoreboard reading ----------

    private static Double readBalance(ClientLevel level, String keyword) {
        String kw = keyword.toLowerCase(Locale.ROOT).trim();
        if (kw.isEmpty()) return null;

        Scoreboard sb = level.getScoreboard();
        Objective obj = sb.getDisplayObjective(DisplaySlot.SIDEBAR);
        if (obj == null) return null;

        List<PlayerScoreEntry> entries = new ArrayList<>(sb.listPlayerScores(obj));
        entries.sort((a, b) -> Integer.compare(b.value(), a.value())); // top line first, like the sidebar

        List<String> lines = new ArrayList<>();
        for (PlayerScoreEntry e : entries) {
            PlayerTeam team = sb.getPlayersTeam(e.owner());
            Component name = PlayerTeam.formatNameForTeam(team, e.ownerName());
            lines.add(name.getString());
        }

        for (int i = 0; i < lines.size(); i++) {
            String s = lines.get(i);
            int idx = s.toLowerCase(Locale.ROOT).indexOf(kw);
            if (idx < 0) continue;
            Double v = parseFirst(s.substring(idx + kw.length()));        // "Money 1.2M"
            if (v == null) v = parseLast(s.substring(0, idx));            // "1.2M Money"
            if (v == null && i + 1 < lines.size()) v = parseFirst(lines.get(i + 1)); // value on next line
            if (v != null) return v;
        }
        return null;
    }

    private static Double toValue(Matcher m) {
        try {
            double n = Double.parseDouble(m.group(1).replace(",", ""));
            String suffix = m.group(2);
            if (suffix != null) {
                switch (Character.toLowerCase(suffix.charAt(0))) {
                    case 'k': n *= 1e3; break;
                    case 'm': n *= 1e6; break;
                    case 'b': n *= 1e9; break;
                    case 't': n *= 1e12; break;
                    default: break;
                }
            }
            return n;
        } catch (NumberFormatException e) {
            return null;
        }
    }

    private static Double parseFirst(String s) {
        Matcher m = NUMBER.matcher(s);
        return m.find() ? toValue(m) : null;
    }

    private static Double parseLast(String s) {
        Matcher m = NUMBER.matcher(s);
        Double last = null;
        while (m.find()) last = toValue(m);
        return last;
    }

    // ---------- formatting ----------

    public static String format(double v, boolean compact) {
        double a = Math.abs(v);
        if (!compact) return String.format(Locale.US, "%,.0f", a);
        String[] suffix = {"", "K", "M", "B", "T"};
        int i = 0;
        while (a >= 1000 && i < suffix.length - 1) {
            a /= 1000;
            i++;
        }
        if (i == 0) return String.format(Locale.US, "%.0f", a);
        String s = String.format(Locale.US, "%.2f", a).replaceAll("0+$", "").replaceAll("\\.$", "");
        return s + suffix[i];
    }

    public static String signed(double v, boolean compact) {
        return (v >= 0 ? "+$" : "-$") + format(v, compact);
    }
}
