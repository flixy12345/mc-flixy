# Aurora Sky + Center HUD + Money Tracker

[![build](https://github.com/YOUR-USERNAME/auroramod/actions/workflows/build.yml/badge.svg)](https://github.com/YOUR-USERNAME/auroramod/actions/workflows/build.yml)

A client-side **Fabric** mod for **Minecraft 1.21.11**.

- **Aurora borealis sky** - animated, glowing curtains over the night sky. Drawn with a custom render
  pipeline (additive blend, depth-tested), so terrain covers it correctly.
- **Smooth HUD slide** - press **V** and the hotbar, health, hunger, armor, XP bar and item name glide to
  just under the crosshair. Press again to glide back. The camera never moves.
- **DonutSMP money tracker** - tracks how much you make and lose, with a live HUD panel.
- **In-game settings screen** (press **K**) with live preview and a lot of visual options.

> **Status:** ported to 1.21.11 and built from the Fabric 1.21.11 docs. It has not been verified in-game
> yet, so please open an issue with your `latest.log` if anything crashes or looks wrong.

## Install
1. Install [Fabric Loader](https://fabricmc.net/use/installer/) 0.18.1+ for Minecraft 1.21.11 and Java 21.
2. Put [Fabric API](https://modrinth.com/mod/fabric-api) (0.141.x for 1.21.11) and `auroramod-*.jar`
   (from the [Releases](../../releases) page) in your `mods` folder.

## Keys (rebind under Controls > Aurora Mod)
| Key | Action |
| --- | --- |
| `V` | Slide the HUD to the center / back (or hold, if "Hold key" is on) |
| `K` | Open the settings screen |
| unbound | Reset the money session |

## Settings
Everything applies live and is saved to `config/auroramod.json`.

| Tab | What you can change |
| --- | --- |
| Aurora | on/off, intensity, coverage, horizon glow, top fade, base/top height, rotation, daytime visibility, rain dimming, quality (Low-Ultra) |
| Motion | speed, waves, shimmer, ray density, flicker, color cycling |
| Colors | presets (Classic, Polar, Violet, Crimson, Sunset, Ice, Rainbow, Custom), hue shift, saturation |
| Custom | RGB sliders for the bottom / middle / top colors |
| HUD | slide on/off, hold-vs-toggle, duration, 6 easing curves, gap under crosshair, horizontal offset, scale, which elements move |
| Money | tracking on/off, server filter, scoreboard line, reset session / all-time |
| Display | money panel corner, offsets, scale, background, which lines show, compact numbers |

## DonutSMP money tracker
Reads the "Money" line of the sidebar scoreboard that the server already sends you and counts every
change in the balance as money earned or lost. The panel shows balance, session net, earned, lost,
per-hour rate, session time, an all-time total and your most recent changes.

- It only runs on servers whose address contains `donutsmp` (changeable in the settings).
- It is passive: it only reads the scoreboard. **There is no network code in this mod at all.**
- The scoreboard shows abbreviated numbers (like `1.25M`), so changes smaller than that rounding can't be seen.
- Every balance change counts, including `/pay`, shop purchases, `/sell` and auction sales.
- If the settings say "Waiting for a scoreboard line...", set **Money > Scoreboard line** to the word
  the sidebar shows next to your balance.

## Build from source
Requires JDK 21.

```sh
# one-time: create the Gradle wrapper (or copy it from a template at https://fabricmc.net/develop)
gradle wrapper --gradle-version 9.2.1

./gradlew build
```

The jar is written to `build/libs/auroramod-<version>.jar`. If a version in `gradle.properties` doesn't
resolve, take the current ones from <https://fabricmc.net/develop>. If Loom 1.15 gives you trouble, the
version Fabric's 1.21.11 migration guide names is Loom 1.14 (`id 'fabric-loom' version '1.14-SNAPSHOT'`).

This project uses Mojang's official mappings and has no mixins: the sky draws through Fabric's
`WorldRenderEvents` and the HUD slide wraps vanilla elements through `HudElementRegistry`.

## Releases
GitHub Actions builds every push and pull request. To publish a release, push a version tag:

```sh
git tag v1.0.0
git push origin v1.0.0
```

The workflow builds the mod and attaches the jars to a new GitHub Release.

## License
[MIT](LICENSE)
